from project.food import Food
from project.fruit import Fruit

food = Food("2024-12-01")
fruit = Fruit("banana", "2024-12-02")

print(fruit)
